# 
# Exemplo de processamento e parse de HTML
#
from html.parser import HTMLParser
