# 
# Arquivo com exemplo de tratamento de XML
#

import xml.dom.minidom