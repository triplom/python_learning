#
# Escrevendo arquivos com funções do Python
#
