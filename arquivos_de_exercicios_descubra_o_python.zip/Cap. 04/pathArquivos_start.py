#
# Arquivo com exemplos de como trabalhar com paths
#

from os  import path
import time