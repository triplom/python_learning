#
# Lendo arquivos com funções do Python
#
