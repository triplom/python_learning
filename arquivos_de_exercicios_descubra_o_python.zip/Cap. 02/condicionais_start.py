#
# Arquivo de exemplo das estruturas condicionais
#
