#
# Arquivo com exemplos de funções
#

# definindo uma função básica


# função que recebe argumentos


# função que retorna um valor

