#
# Exemplo de como usar os comando Break e Continue
#
