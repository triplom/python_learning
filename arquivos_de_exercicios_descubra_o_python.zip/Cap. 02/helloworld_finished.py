#
# Exemplo de código para escrever Hello World!
#

print("Hello World")
