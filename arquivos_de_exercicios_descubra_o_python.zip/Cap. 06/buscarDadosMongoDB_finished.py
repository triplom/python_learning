# 
# Exemplo de acesso a uma base de dados SQLite
#
import pymongo
from pymongo import MongoClient